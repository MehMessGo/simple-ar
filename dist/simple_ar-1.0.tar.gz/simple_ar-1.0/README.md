# simple_ar
AR Python3-модуль для обнаружения маркеров на OpenCV

Обнаружение аруко маркеров:

![alt text](https://github.com/MehMessGo/simple_ar/blob/master/example.png?raw=true)
