"""
:authors: Michael Pakhmurin
:license: MIT License, see LICENSE file

:copyright: (c) 2020 Michael Pakhmurin
"""

from .rescale import rescale
from .ar import *
